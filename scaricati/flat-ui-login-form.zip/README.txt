A Pen created at CodePen.io. You can find this one at http://codepen.io/bbodine1/pen/fhLAg.

 Self Contained SCSS. 

Forked from http://cssdeck.com/labs/flat-ui-login-form
by: http://codepen.io/davideast